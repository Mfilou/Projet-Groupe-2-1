#include <stdio.h>
#include <stdlib.h>
#include "prototype.h"
#include "structure.h"


int main()
{
    menu(parc());
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prototype.h"
#include "structure.h"



Liste *initialisation(int nombre_de_voiture)
{
    Liste *liste = malloc(sizeof(*liste));
    Voiture *voiture = malloc(sizeof(*voiture));
    if (liste == NULL || voiture == NULL)
    {
        exit(EXIT_FAILURE);
    }
    voiture->n1 = nombre_de_voiture;
    voiture->modele = "RAV4 1999";
    voiture->immatriculation = "AB1020";
    voiture->kilometrage = 0;
    voiture->etat = "Disponible";

    voiture->suivant = NULL;
    liste->premier = voiture;

    liste->nombre_voiture = 1;
    return liste;
}

void insertion(Liste *liste, int n1, char *nv_modele,char *nv_immatriculation,float nv_kilometrage,char *nv_etat)
{
    /* Cr�ation du nouvel �l�ment */
    Voiture *nouveau = malloc(sizeof(*nouveau));
    if (liste == NULL || nouveau == NULL)
    {
        exit(EXIT_FAILURE);
    }
    nouveau->n1 = n1;
    nouveau->modele = nv_modele;
    nouveau->immatriculation = nv_immatriculation;
    nouveau->kilometrage = nv_kilometrage;
    nouveau->etat = nv_etat;

    /* Insertion de l'�l�ment au d�but de la liste */
    nouveau->suivant = liste->premier;
    liste->premier = nouveau;

    liste->nombre_voiture += 1;
}

//Suppression de l'�l�ment d'ent�te de la liste
void suppression(Liste *liste)
{
    if (liste == NULL)
    {
        exit(EXIT_FAILURE);
    }
    if (liste->premier != NULL)
    {
        Voiture *a_supprimer = liste->premier;
        liste->premier = liste->premier->suivant;
        free(a_supprimer);

        liste->nombre_voiture -= 1;
    }
}

Voiture *recupere_a_la_position(Liste *liste, int position)
{
    if(liste == NULL || liste->premier == NULL)
        exit(EXIT_FAILURE);

    if(position >= 1)
    {
        Voiture *voit_a_recuperer = liste->premier;
        if(position == 1)
            return voit_a_recuperer;
        int rang = 1;
        while(voit_a_recuperer->suivant != NULL)
        {
            voit_a_recuperer = voit_a_recuperer->suivant;
            rang++;
            if(rang == position)
                return voit_a_recuperer;
        }
    }
    return NULL;
}

void changer_etat(Voiture *voiture_d_etat_a_changer, char *etat)
{
    if(voiture_d_etat_a_changer != NULL)
        voiture_d_etat_a_changer->etat = etat;
}


void affiche_voiture(Voiture *voiture_a_afficher)
{
    if(voiture_a_afficher != NULL)
    {
        printf("\nVoiture  %d", voiture_a_afficher->n1);
        printf("\nModele : %s", voiture_a_afficher->modele);
        printf("\nImmatriculation : %s", voiture_a_afficher->immatriculation);
        printf("\nKilometrage : %.2f km", voiture_a_afficher->kilometrage);
        printf("\nEtat : %s\n\n", voiture_a_afficher->etat);
    }
    else
    {
        exit(0);
    }
}

void afficherListe(Liste *liste)
{
    if (liste == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Voiture *actuel = liste->premier;
    while (actuel != NULL)
    {
        affiche_voiture(actuel);
        actuel = actuel->suivant;
    }
}

//LES FONCTIONS CHERCHER


Voiture *cherche_modele(char *info, Liste *p)
{
    if (p == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Voiture *prem = p->premier;
    while(prem != NULL)
    {
        if(strcmp(prem->modele, info) == 0)
            return prem;
        prem = prem->suivant;
    }
    return NULL;
}

Voiture *cherche_immatriculation(char *info, Liste *p)
{
    if (p == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Voiture *prem = p->premier;
    while(prem != NULL)
    {

        if(strcmp(prem->immatriculation, info) == 0)
            return prem;
            prem = prem->suivant;
    }
    return NULL;
}

Voiture *cherche_kilometrage(float info, Liste *p)
{
    if (p == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Voiture *prem = p->premier;
    while(prem != NULL)
    {
        if(prem->kilometrage == info)
            return prem;
        prem = prem->suivant;
    }
    return NULL;
}


/*void insertion_milieu(Liste *liste, int n1, char *nv_modele,char *nv_immatriculation,float nv_kilometrage,char *nv_etat)
{
    // Cr�ation du nouvel �l�ment
    Voiture *nouveau = malloc(sizeof(*nouveau));
    if (liste == NULL || nouveau == NULL)
    {
        exit(EXIT_FAILURE);
    }
    nouveau->n1 = n1;
    nouveau->modele = nv_modele;
    nouveau->immatriculation = nv_immatriculation;
    nouveau->kilometrage = nv_kilometrage;
    nouveau->etat = nv_etat;

    // Insertion de l'�l�ment a une position n de la liste
    nouveau->suivant = liste->milieu;
    liste->milieu = nouveau;


    liste->nombre_voiture += 1;
}*/

/*void afficherListe(Liste *liste)
{
    if (liste == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Voiture *actuel = liste->premier;
    while (actuel != NULL)
    {
        affiche_voiture(actuel);
        actuel = actuel->suivant;
    }
}*/

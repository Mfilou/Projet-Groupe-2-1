#include <stdio.h>
#include <stdlib.h>
#include "prototype.h"
#include "structure.h"

Liste *parc()
{

    int nombre_de_voiture = 10;
    int n = nombre_de_voiture;
    Liste *maliste = initialisation(nombre_de_voiture);

    insertion(maliste, --n, "RAV4 2001", "AB1030", 150, "Disponible");
    insertion(maliste, --n, "RAV4 2007", "AB1213", 22, "Disponible");
    insertion(maliste, --n, "RAV6 2018", "AG1100", 1000, "Disponible");
    insertion(maliste, --n, "BWM6 2008", "AG1870", 130, "Disponible");
    insertion(maliste, --n, "Lexus", "AC3054", 100, "Disponible");
    insertion(maliste, --n, "Mazda 623", "AZ8793", 180, "Disponible");
    insertion(maliste, --n, "Toyota", "AF3000", 300, "Disponible");
    insertion(maliste, --n, "Mercedes 234", "AR3747", 502, "Disponible");
    insertion(maliste, --n, "Group1 387", "AS4938", 676, "Disponible");
   // printf("%d", maliste->nombre_voiture);
    //Voiture * rec = recupere_a_la_position(maliste, 1);
    //affiche_voiture(rec);
 //   int n_tot = n - 1;
  //  printf("%d", n_tot);
    //afficherListe(maliste);
    return maliste;
}

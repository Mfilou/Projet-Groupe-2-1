#include <stdio.h>
#include <stdlib.h>
#include "prototype.h"
#include "structure.h"


void menu (Liste *liste_retournee)
{
    int choix;
   // char* num_immat = NULL;

    printf("======= Menu =======\n");
    printf("1: Louer une voiture\n");
    printf("2: Retour d'une voiture\n");
    printf("3: Etat d'une voiture\n");
    printf("4: Etat du parc de voitures\n");
    printf("5: Sauvegarder l�etat du parc \n");
    printf("0: Fin du programme \n\n");
    printf("De quel service avez-vous besoin? \n");
    scanf("%d", &choix);

    while (choix <0 || choix > 5)
    {
        printf("Nous n'offrons pas ce service\n");
        printf("Veuillez en choisir dans notre menu: ");
        scanf("%d", &choix);
    }

    switch (choix)
    {
        case 1:

            louer_voiture();
            break;
        case 2:
            retour_voiture();
            break;
        case 3:
            etat_voiture();
            break;
        case 4:
            printf(" =========Etat du parc de voitures=========\n");
            afficherListe(liste_retournee);

            printf("\nFonctionnalite en cours de programmation");
            printf("\nVeuillez patienter jusqu'a la prochaine mise a jour");
            break;
        case 5:
            printf("=========Sauvegarder l��tat du parc========= \n");
            printf("\nFonctionnalite en cours de programmation");
            printf("\nVeuillez patienter jusqu'a la prochaine mise a jour");
            break;
        case 0:
            system("cls");
            printf("0: Fin du programme \n\n");
            exit(0);
            break;
    }
    int retour_menu = 0;
    printf("Voulez vous retourner au Menu ?\n");
    printf("1=oui, 2=non\n");
    scanf("%d", &retour_menu);
    if(retour_menu == 1)
    {
        system("cls");
        menu(liste_retournee);
    }
    else if(retour_menu == 2)
    {
        exit(0);
    }
}

void louer_voiture()
{
    printf("\n1: =======Louer une voiture=======\n");

        //
            char num_immat[100];
            Liste *liste_ma;
            liste_ma = parc();
            printf("\nEntrez le numero d'immatriculation de la voiture a louer\n");
            scanf("%s", num_immat);
            Voiture *voiture_trouvee;
            voiture_trouvee = cherche_immatriculation(num_immat, liste_ma);

            while(voiture_trouvee == NULL)
            {
                printf("\nERREUR ! La voiture recherchee n'existe pas");
                printf("\nVeuillez entrer un numero d'immatriculation valide\n");
                scanf("%s", num_immat);
                voiture_trouvee = cherche_immatriculation(num_immat, liste_ma);
            }

            if(voiture_trouvee != NULL)
            {
                system("cls");
                affiche_voiture(voiture_trouvee);
                int confirmation = 0;
                printf("Voulez-vous confirmer la location de cette voiture?\n");
                printf("\n1- Oui\n2- Non\n");
                scanf("%d", &confirmation);
                if(confirmation == 1)
                {
                    printf("Felicitation ! Location confirmee.");
                    changer_etat(voiture_trouvee, "En Location");
                    //voiture_trouvee->etat = "En Location";
                    affiche_voiture(voiture_trouvee);
                }
                else
                {
                    printf("\nLocation Annulee");
                }

                int rouvrir = 0;
                printf("\n\nAutre location?\n1. Oui\n2. Non\n");
                scanf("%d", &rouvrir);
                while(rouvrir == 1)
                {
                    louer_voiture();
                    printf("\n\nAutre location?\n1. Oui\n2. Non\n");
                    scanf("%d", &rouvrir);
                }
            }

}

void retour_voiture()
{
    printf("\n1: =======Retour d'une voiture=======\n");

    char num_immat[8];
    Liste *liste_ma;
    liste_ma = parc();
    printf("\nEntrez le numero d'immatriculation de la voiture a retourer\n");
    scanf("%s", num_immat);
    Voiture *voiture_a_retourner;
    voiture_a_retourner = cherche_immatriculation(num_immat, liste_ma);


    while(voiture_a_retourner == NULL)
    {
        printf("\nERREUR ! La voiture a retourner n'existe pas");
        printf("\nVeuillez entrer un numero d'immatriculation valide\n");
        scanf("%s", num_immat);
    }


            if(voiture_a_retourner != NULL)
            {
                system("cls");
                voiture_a_retourner->etat = "En Location";
                affiche_voiture(voiture_a_retourner);
                int confirmation = 0;
                printf("Voulez-vous confirmer le retour de cette voiture?\n");
                printf("\n1- Oui\n2- Non\n");
                scanf("%d", &confirmation);
                if(confirmation == 1)
                {
                    printf("Bravo ! Vous venez de confirmer le retour de cette voiture\n");
                    changer_etat(voiture_a_retourner, "Disponible");
                    affiche_voiture(voiture_a_retourner);
                }
                else
                {
                    printf("\nRetour Annulee");
                }

                int rouvrir = 0;
                printf("\n\nAutre retour de voiture?\n1. Oui\n2. Non\n");
                scanf("%d", &rouvrir);
                while(rouvrir == 1)
                {
                    louer_voiture();
                    printf("\n\nAutre retour de voiture?\n1. Oui\n2. Non\n");
                    scanf("%d", &rouvrir);
                }
            }

}


void etat_voiture()
{
    printf("\n1: =======Etat d'une voiture=======\n");

        //
            char num_immat[100];
            Liste *liste_ma;
            liste_ma = parc();
            printf("\nEntrez le numero d'immatriculation de la voiture dont vous voulez connaitre l'etat\n");
            scanf("%s", num_immat);
            Voiture *voiture_trouvee;
            voiture_trouvee = cherche_immatriculation(num_immat, liste_ma);

            while(voiture_trouvee == NULL)
            {
                printf("\nERREUR ! La voiture recherchee n'existe pas");
                printf("\nVeuillez entrer un numero d'immatriculation valide\n");
                scanf("%s", num_immat);
                voiture_trouvee = cherche_immatriculation(num_immat, liste_ma);
            }

            if(voiture_trouvee != NULL)
            {
                system("cls");
                affiche_voiture(voiture_trouvee);
            }

            int rouvrir = 0;

            while(rouvrir == 1)
            {
                etat_voiture();
                printf("\n\nVoulez-vous voir l'etat d'une autre voiture ?\n1. Oui\n2. Non\n");
                scanf("%d", &rouvrir);
            }
}

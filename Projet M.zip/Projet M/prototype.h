#ifndef PROTOTYPE_H_INCLUDED
#define PROTOTYPE_H_INCLUDED

typedef struct Voiture Voiture;
struct Voiture
{
    int n1;
    char *modele;
    char *immatriculation;
    float kilometrage;
    char *etat;
    Voiture *suivant;
};


typedef struct Liste Liste;
struct Liste
{
    Voiture *premier;
    int nombre_voiture;
};



void menu();
Liste *parc();
Voiture *recupere_a_la_position(Liste *liste, int position);
void affiche_voiture(Voiture *);
void suppression();
void afficherListe(Liste*);
Liste *initialisation(int nombre_de_voiture);
void changer_etat(Voiture *voiture_d_etat_a_changer, char *etat);
void louer_voiture();
void retour_voiture();
void etat_voiture();
void insertion(Liste *liste, int n1, char *nv_modele,char *nv_immatriculation,float nv_kilometrage,char *nv_etat);


Voiture *cherche_marque(char *info, Liste *p);
Voiture *cherche_modele(char *info, Liste *p);
Voiture *cherche_immatriculation(char *info, Liste *p);
Voiture *cherche_kilometrage(float info, Liste *p);
Voiture *cherche_etat(char *info, Liste *p);

#endif // PROTOTYPE_H_INCLUDED
